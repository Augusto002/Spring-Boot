package com.talents.testtalents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestTalentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestTalentsApplication.class, args);
	}

}
