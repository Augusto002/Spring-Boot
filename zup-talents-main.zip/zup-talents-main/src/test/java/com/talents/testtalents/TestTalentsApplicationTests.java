package com.talents.testtalents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTalentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
